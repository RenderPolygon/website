print("""🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼
🌼     welcome to TextThing 📝    🌼
🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼🌼""")
print("""

TextThing is a very simple text editor that
you can use to write a text file!""")
print("——————————————————————————————————————————")
print("you can start typing your text now!")
print("commands:")
print("""🌼 :w filename.txt   save
🌼 :o filename.txt   open
🌼 :q                quit
🌼 :wq filename.txt  save and quit

⬇️ :j = down | ⬆️ :k = up""")
print("——————————————————————————————————————————")

lines = [""] # this list holds every line of text in the file

cursor = 0 # the cursor points to the current line you're editing


# this function shows the editor view
def show():
    print("——————————————————————————————————————————")
    for i, l in enumerate(lines):
        # show a > next to the line where the cursor is
        if i == cursor:
            print(f"> {i+1}: {l}")
        else:
            print(f"  {i+1}: {l}")
    print("——————————————————————————————————————————")

# LOOP
while True:
    line = input()
    # user input

    # quit
    if line == ":q":
        print("bye")
        break

    # OPEN FILE
    if line.startswith(":o "):
        filename = line[3:]
        try:
            with open(filename, "r", encoding="utf-8") as f:
                # read file lines and remove newline characters
                lines = [l.rstrip("\n") for l in f]

            # make sure the editor is never empty
            if not lines:
                lines = [""]

            # reset cursor
            cursor = 0
            print(f"opened {filename}")
            show()
        except FileNotFoundError:
            print("☢️ file not found")
        continue

    # SAVE/WRITE
    if line.startswith(":w "):
        filename = line[3:]
        with open(filename, "w", encoding="utf-8") as f:
            for l in lines:
                f.write(l + "\n")
        print(f"📝 saved to {filename}")
        continue

    # GO DOWN
    if line == ":j":
        if cursor < len(lines) - 1:
            cursor += 1
        else:
            # if you are at the bottom, add a new empty line
            lines.append("")
            cursor += 1
        show()
        continue

    # GO UP
    if line == ":k":
        if cursor > 0:
            cursor -= 1
        show()
        continue

    # edit line
    # whatever you type replaces the line that the cursor is at
    lines[cursor] = line
    show()

# this was hell to make


# 100